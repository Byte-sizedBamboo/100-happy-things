import streamlit as st
import json
import os

st.set_page_config(page_title="我的小幸福合集", page_icon="📖")

st.markdown("""
# 📖 我的 100 件小幸福合集

> 回顾这些微小却真实的幸福时刻 🌸

---
""")

# 读取数据
DATA_FILE = "data.json"

if os.path.exists(DATA_FILE):
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        happiness_list = json.load(f)
else:
    happiness_list = [""] * 100

# 过滤非空项
non_empty_happiness = [(i+1, item.strip()) for i, item in enumerate(happiness_list) if item.strip() != ""]

if non_empty_happiness:
    for i, text in non_empty_happiness:
        st.markdown(f"**{i}.** {text}")
else:
    st.info("你还没有填写任何小幸福哦～去填写页记录一些吧！🌱")